from django.apps import AppConfig


class CodevilleConfig(AppConfig):
    name = 'codeville'
